﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class SaveLoadManager : MonoBehaviour
{
    //public GameObject AnimWindow;
    //Animator animWindowMator;
    public Transform PlayerTransform;
    float PlayerPositionx = -40;
    float PlayerPositiony = (float)-113.6;
    private void Start()
    {
        /*AnimWindow = GameObject.Find("AnimWindow");
        animWindowMator = AnimWindow.GetComponent<Animator>();
        AnimWindow.SetActive(false);*/
    }

    private void Update()
    {
        PlayerPositionx = PlayerTransform.position.x;
        PlayerPositiony = PlayerTransform.position.y;
    }

    public void SavingData()
    {
        PlayerPrefs.SetFloat("posX", PlayerPositionx);
        PlayerPrefs.SetFloat("posY", PlayerPositiony);
        PlayerPrefs.Save();
        //StartCoroutine(waitingForAnimation("Save"));
    }

    public void LoadingData()
    {
        if (PlayerPrefs.HasKey("posX") || PlayerPrefs.HasKey("posY"))
        {
            PlayerPositionx = PlayerPrefs.GetFloat("posX");
            PlayerPositiony = PlayerPrefs.GetFloat("posY");
            PlayerTransform.position = new Vector2(PlayerPositionx, PlayerPositiony);
        }
    }

    public void LoadingData(float x, float y)
    {
            PlayerPositionx = x;
            PlayerPositiony = y;
            PlayerTransform.position = new Vector2(PlayerPositionx, PlayerPositiony);
    }
    public void NewGame()
    {
        PlayerTransform.position = (new Vector2(-40, (float)-113.6));
    }
    
    /*public IEnumerator waitingForAnimation (string trigger)
    {
        AnimWindow.SetActive(true);
        animWindowMator.SetTrigger(trigger);
        yield return new WaitForSeconds(1f);
        AnimWindow.SetActive(false);
    }*/
}
